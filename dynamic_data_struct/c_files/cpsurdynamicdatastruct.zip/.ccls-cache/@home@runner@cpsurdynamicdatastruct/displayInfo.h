#ifndef __DISPLAYINFO_H__
#define __DISPLAYINFO_H__

void displayInfo();

#endif 