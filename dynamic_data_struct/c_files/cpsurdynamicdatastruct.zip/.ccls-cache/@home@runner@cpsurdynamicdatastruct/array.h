#ifndef __ARRAYS_H__
#define __ARRAYS_H__

#define MAX_ARRAY_SIZE 10

void initializeArray(int arr[], int size);
void printArray(int arr[], int size);
int sumArray(int arr[], int size);

#endif